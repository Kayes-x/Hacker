//
//  HackingEntry.h
//  HackingFacebook
//
//  Created by wutian on 2017/2/14.
//  Copyright © 2017年 Weibo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HackingEntry : NSObject

@end
